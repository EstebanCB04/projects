# Gestión de Productos en una Tienda Virtual

Esta es una aplicacion desarrollada en PHP aplicando la separacion 
de responsabilidades entre modelo, vista y controlador, además de realizar operaciones
CRUD (Crear, Leer, Actualizar, Eliminar).

Para poder ejecutarla primero se debe instalar XAMPP a traves de este link
https://www.apachefriends.org/es/download.html

Despues de realizar dicha instalacion tendra que activar los servicios Apache Web Server y posteriormente MySql Database.

Recuerde que esta aplicacion debe estar en la carpeta htdocs de la carpeta XAMPP en su disco local //:C para poder ingresar a la aplicacion.

Luego teniendo activado los servicios ya mencionados tiene que dirigirse
a la siguiente URL:
http://localhost/phpmyadmin/

Una vez estando en la interfaz de phpmyadmin tendrá que utilizar
el archivo SQL que se encuentra en la carpeta "sql" para crear la Base de Datos
y no tener ningún otro problema.

Ahora tendra que ingresar a esta URL para poder ingresar a la aplicacion para poder interactuar
con distintas operaciones.
http://localhost/tienda_virtual/public/

Despues de realizar estos pasos usted habra podido crear un producto con nuestra aplicacion.
