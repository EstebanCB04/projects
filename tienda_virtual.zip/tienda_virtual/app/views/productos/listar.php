<center>
<h1>Listado de Productos</h1>
<style>
    table {
        width: 80%;
        margin: 20px auto;
        border-collapse: collapse;
    }

    table, th, td {
        border: 1px solid black;
    }

    nav, th, td {
        padding: 10px;
        text-align: center;
    }

    th {
        background-color: #f4f4f4;
    }
</style>

<a href="index.php?action=crear">Crear Producto</a>
<table>
    <tr>
        <th>Nombre</th>
        <th>Descripción</th>
        <th>Precio</th>
        <th>Stock</th>
        <th>Acciones</th>
    </tr>
    <?php foreach ($productos as $producto): ?>
        <tr>
            <td><?php echo $producto['nombre']; ?></td>
            <td><?php echo $producto['descripcion']; ?></td>
            <td><?php echo $producto['precio']; ?></td>
            <td><?php echo $producto['stock']; ?></td>
            <td>
                <a href="index.php?action=editar&id=<?php echo $producto['id_producto']; ?>">Editar</a>
                <a href="index.php?action=eliminar&id=<?php echo $producto['id_producto']; ?>">Eliminar</a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>
</center>