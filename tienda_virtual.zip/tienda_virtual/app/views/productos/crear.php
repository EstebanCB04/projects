<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Crear Producto</title>
</head>
<body>
    <center>
    <h1>Crear Producto</h1>
    <form method="POST" action="/tienda_virtual/public/index.php?controller=producto&action=crear">
        <label>Nombre:</label>
        <input type="text" name="nombre" required>
        <label>Descripción:</label>
        <input type="text" name="descripcion" required>
        <label>Precio:</label>
        <input type="number" name="precio" step="0.01" required>
        <label>Stock:</label>
        <input type="number" name="stock" required>
        <a ref="../../public/index.php">
            <button type="submit">Guardar</button>
        </a>
    </form>
    </center>
</body>
</html>

