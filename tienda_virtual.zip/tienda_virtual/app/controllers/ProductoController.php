<?php
require_once __DIR__ . '/../models/Producto.php';
class ProductoController {
    private $producto;
    public function __construct($pdo) {
        $this->producto = new Producto($pdo);
    }

    public function listar() {
        $productos = $this->producto->listar();
        require_once dirname(__FILE__) . '/../views/productos/listar.php';
    }

    public function crear() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $nombre = $_POST['nombre'];
            $descripcion = $_POST['descripcion'];
            $precio = $_POST['precio'];
            $stock = $_POST['stock'];
            $this->producto->crear($nombre, $descripcion, $precio, $stock);
            header("Location: /tienda_virtual/public/");
        } else {
            require_once __DIR__ . "/../views/productos/crear.php";
        }
    }

    public function editar($id) {
        $producto = $this->producto->obtenerPorId($id);
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $nombre = $_POST['nombre'];
            $descripcion = $_POST['descripcion'];
            $precio = $_POST['precio'];
            $stock = $_POST['stock'];
            $this->producto->editar($id, $nombre, $descripcion, $precio, $stock);
            header("Location: /tienda_virtual/public/");
        } else {
            require_once '../app/views/productos/editar.php';
        }
    }

    public function eliminar($id) {
        $this->producto->eliminar($id);
        header("Location: /tienda_virtual/public/");
    }
}
