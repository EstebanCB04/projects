CREATE DATABASE tienda_virtual;
USE tienda_virtual;

CREATE TABLE productos (
    id_producto INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT NOT NULL,
    precio DECIMAL(8, 2) NOT NULL,
    stock INT NOT NULL
);